Well this is simple NOte pad which , i made after studying following topics of c++ ,
     1-Loops .
      2-Functions .
     3-Arrays .
     4 - Pointers .
      5-Simple file handling .
        6- and Little Bit Graphics (which is not concern in my program ) .
  i think , this program will be good explantory for new users . if you think this program can be add in your list then please inform me . ok
 Thanks

_______________________________________________________________
From: "Zahid Ashfaq" <zahidashfaq@hotmail.com> 
Date: Sun, 19 Aug 2001 18:10:18 
