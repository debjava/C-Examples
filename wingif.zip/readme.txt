GIFVIEW.
Example on how to load and display an animated GIF file in Windows using the
cplusplus.com's WinImage library.
-------------------------------------------------------------------------------

GIFVIEW Package files:
- GIFVIEW.CPP - Main Source File
- GIFVIEW.DSP - Visual Development Studio 6.0 Project File
- GIFVIEW.EXE - Compiled Result.
- SAMPLE.GIF  - Sample GIF Image.
- LOGO.BMP    - Sample BMP Image.
- README.TXT  - This.

WINIMAGE library files:
- WINIMAGE.H   - Header file with the WINIMAGE library class declarations.
- WINIMAGE.CPP - Header file with the WINIMAGE library member definitions.
- WINIMAGE.TXT - Winimage's Readme.txt

If you use a command line compiler:
- Compile as Win32 all the files that have .CPP extension, keep the .H files
  accessible.
- Link them together.

If you use an environment:
- Create a new Win32 project and add all the .CPP files to it.
- Build.
  (If you use Visual C++ 6.0 you may use the GIFVIEW.DSP project file provided)

Refer to companion WINIMAGE.TXT for more info on WINIMAGE library.
If redistributed, include this README.TXT file.

-------------------------------------------------------------------------------
                            November 2000, Juan Soulie <jsoulie@cplusplus.com>
-------------------------------------------------------------------------------

      "The Graphics Interchange Format(c) is the Copyright property of
      CompuServe Incorporated. GIF(sm) is a Service Mark property of
      CompuServe Incorporated."
