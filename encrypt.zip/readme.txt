An encryption program I made using the vigenere algorithm.
 
Sam Alexander

___________________________________________________________________
Received on May 20, 2001 from "Sam Alexander" <sama102@hotmail.com> 

The C++ Resources Network
http://www.cplusplus.com