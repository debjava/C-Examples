//Message.h
#ifndef MESSAGE_H
#define MESSAGE_H

class Message
{
	public:
		Message(const char* pStr, const char* key);
		Message(const char* pStr);
		Message();
		
		void encryptMessage();
		void decryptMessage();
		
		const char* getUnMessage() const;
		const char* getEnMessage() const;
		
		void getMessage();
		void getKey();
		
		~Message();
		
	private:
		char* pUnMessage;
		char* pEnMessage;
		char* pKey;
};

#endif