// file downloader
// download files off the world wide web
// written by Jared Bruni
// www.lostsidedead.com


// preproccescor directives, include correct librarys
#include <windows.h>
#include <urlmon.h>
#include "resource.h"
#include "masterstring.h"

#define BGO 12
// programs important varaibles
HFONT  prog_font = CreateFont(16,0,0,0,FW_DONTCARE,0,0,0,ANSI_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,DEFAULT_QUALITY,FF_MODERN,"Arial");
HINSTANCE hInst;
HWND      hwnd;
HWND      edit;
HWND      bgo; // button go
HWND      html_view;
WNDPROC   oldproc;


// callback functions
LRESULT APIENTRY MainProc(HWND hwnd,UINT msg,WPARAM wParam,LPARAM lParam);
LRESULT APIENTRY EditProc(HWND hwnd,UINT msg,WPARAM wParam,LPARAM lParam);
// useful functions
inline void Init(void);
inline void SetMyFont(HWND hwnd);
// go get it 
void onGet();

// entry point
int APIENTRY WinMain(HINSTANCE hInstx,HINSTANCE hPrev,LPSTR line,int CmdShow)
{
	MSG msg;

	hInst = hInstx;
	Init();

	while(GetMessage(&msg,0,0,0))
	{
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}	

	return 0;
}

// initlize
inline void Init(void)
{
	WNDCLASS wc;

	wc.cbClsExtra = 0;
	wc.cbWndExtra = 0;
	wc.hbrBackground = (HBRUSH) GetStockObject(LTGRAY_BRUSH);
	wc.hInstance = hInst;
	wc.hIcon = LoadIcon(hInst,MAKEINTRESOURCE(IDI_ICON1));
	wc.hCursor = LoadCursor(NULL,IDC_ARROW);
	wc.lpfnWndProc = (WNDPROC) MainProc;
	wc.lpszClassName = "MasterURL";
	wc.lpszMenuName = NULL;
	wc.style = CS_HREDRAW | CS_VREDRAW;

	RegisterClass(&wc);

	hwnd = CreateWindow("MasterURL","Master URL Leech",WS_OVERLAPPED | WS_SYSMENU | WS_MINIMIZEBOX,CW_USEDEFAULT,CW_USEDEFAULT,250,250,0,0,hInst,0);

	ShowWindow(hwnd,SW_SHOW);
	UpdateWindow(hwnd);
}
// set the font
inline void SetMyFont(HWND hwnd)
{
	SendMessage(hwnd,WM_SETFONT,(WPARAM)prog_font,0);
}

// main callback
LRESULT APIENTRY MainProc(HWND hwnd,UINT msg,WPARAM wParam,LPARAM lParam)
{

	switch(msg)
	{
	case WM_DESTROY:
		PostQuitMessage(0);
		break;
	case WM_CREATE:
		{
			HWND st;
			HWND st2;
			st = CreateWindow("Static","Enter the Pages URL ",WS_CHILD | WS_VISIBLE,5,5,200,20,hwnd,0,hInst,0);
			edit = CreateWindowEx(WS_EX_STATICEDGE,"Edit","http://www.lostsidedead.com/gameprog/index.html",WS_CHILD | WS_VISIBLE | WS_BORDER | ES_AUTOHSCROLL,5,25,200,20,hwnd,0,hInst,0);
			bgo = CreateWindow("Button","Get!",WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,205,25,35,20,hwnd,(HMENU)BGO,hInst,0);
			st2 = CreateWindow("Static","Downloaded HTML",WS_CHILD | WS_VISIBLE ,5,25+20+5,200,20,hwnd,0,hInst,0);
			html_view = CreateWindowEx(WS_EX_STATICEDGE,"Edit",NULL,WS_CHILD |  ES_READONLY | WS_VISIBLE | ES_MULTILINE | WS_BORDER |  WS_VSCROLL,5,25+20+5+20+5,230,140,hwnd,0,hInst,0);

			oldproc = (WNDPROC) SetWindowLong(edit,GWL_WNDPROC,(LONG)(WNDPROC)EditProc);

			SetMyFont(html_view);
			SetMyFont(st2);
			SetMyFont(bgo);
			SetMyFont(edit);
			SetMyFont(st);
		}
		break;
	case WM_LBUTTONDOWN:
		{
			
			
		}
		break;
	case WM_COMMAND:
		{
			switch(HIWORD(wParam))
			{
			case BN_CLICKED:
				{
					switch(LOWORD(wParam))
					{
					case BGO:
						{
							SendMessage(hwnd,WM_SETTEXT,255,(LPARAM)(LPCSTR)"downloading..");

							onGet();
						}
						break;
					}
				}
				break;
			}
		}
		break;
	default: return DefWindowProc(hwnd,msg,wParam,lParam);
	}

	return 0;
}
// edit callback
LRESULT APIENTRY EditProc(HWND hwnd,UINT msg,WPARAM wParam,LPARAM lParam)
{
	switch(msg)
	{
	case WM_KEYDOWN:
		{
			switch(wParam)
			{
			case VK_RETURN:
				{
						SendMessage(hwnd,WM_SETTEXT,255,(LPARAM)(LPCSTR)"downloading..");

					onGet();
				}
				break;
			}
		}
		break;
	default: return CallWindowProc(oldproc,hwnd,msg,wParam,lParam);
	}
	return 0;
}
// go get it
void onGet()
{
	char urlname[200];
	SendMessage(edit,WM_GETTEXT,200,(LPARAM)(LPCSTR)urlname);
	UpdateWindow(hwnd);
	
	if(URLDownloadToFile(0,urlname,"dfile.html",0,0))
	{
		MessageBox(hwnd,"Error:\nFile Not Found or you are offline","Error",MB_OK | MB_ICONERROR);
		SendMessage(hwnd,WM_SETTEXT,255,(LPARAM)(LPCSTR)"Master URL Leech");
		return;
	}
	else
	{
	
		char* buff;
		buff = new char[getfilestringlength("dfile.html")+20];
		strloadfile("dfile.html",buff);
		SendMessage(html_view,WM_SETTEXT,strlen(buff),(LPARAM)(LPCSTR)buff);
		delete [] buff;
		SendMessage(hwnd,WM_SETTEXT,255,(LPARAM)(LPCSTR)"Master URL Leech");

	}

}
