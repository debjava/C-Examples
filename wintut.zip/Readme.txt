**README.TXT**

Heya!

This is just a bit of source code that shows how to create and
show a window! Hope you find it useful! It was written for 
Borland C++ 5.5 Command Line Tools, but I imagine it will
work with other compilers too :) Note that this has been
done with the Win32 API, and does not use MFC in any way.
WinTut.exe has been packed with UPX to make it smaller &
less of a hassle to download, so don't be surprised if
your compiler makes an EXE twice as big as the one included
with this source!!


-Tommy!!!