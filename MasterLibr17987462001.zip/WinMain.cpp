#include <windows.h>
#include "masterlibrary.h"


int APIENTRY WinMain(HINSTANCE hInst,HINSTANCE hPrev,LPSTR line,int CmdShow)
{

	return 0;
}
